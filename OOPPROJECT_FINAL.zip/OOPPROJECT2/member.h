#ifndef CLASS_member
#define CLASS_member
using namespace std;
void mainmenu();
class member
{
	protected:
	string name;
	string address;
	string phone_no;
	string department;
	//int no_of_books_issue;	
};
#endif

